#!/bin/bash


rose='\e[1;31m'
bleu='\e[1;34m'
neutre='\e[0;m'

#  Lister les services écoutant sur un port réseau
ports=$(sudo netstat -lntup | grep LISTEN | awk -F ":" '{print $2}'| awk -F " " '{print $1}')
for port in $ports
do
        echo -ne  "\n${rose}Le service écoutant sur ${bleu}$port ${rose}est:${bleu}\n"
        sudo netstat -lntup | grep -v tcp6 | grep -v udp6 |grep LISTEN | grep $port | awk -F"/" '{print $2}'
done
echo -ne "${neutre}"


