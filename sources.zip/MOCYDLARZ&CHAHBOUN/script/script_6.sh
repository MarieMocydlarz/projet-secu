#!/bin/bash

rose='\e[1;31m'
bleu='\e[1;34m'
neutre='\e[0;m'

# teste /etc/shadow par john the ripper
echo -ne "${rose} le test des mots de passes qui sont faibles est:${bleu}\n"
sudo /usr/sbin/unshadow /etc/passwd /etc/shadow > /tmp/crack.password.db
john /tmp/crack.password.db

# pour voir les mots de passes crackés
echo -ne "${rose}affichage des mots de passes crackés de /etc/shadow :${bleu}\n"
john -show /tmp/crack.password.db 

echo -ne "${neutre}"

