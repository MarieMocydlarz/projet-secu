#!/bin/bash

rose='\e[1;31m'
bleu='\e[1;34m'
neutre='\e[0;m'

# Vérification de l'integrité du /bin
md5deep -X /home/esclave/Desktop/projet/projet/script/hash_bin.txt -r /bin > /home/esclave/Desktop/projet/projet/script/failed_hash_bin.txt
var1=$(wc -w /home/esclave/Desktop/projet/projet/script/failed_hash_bin.txt | awk '{print $1}')
if [ ! "$var1" = 0 ];
then
echo -ne "${rose}Les fichiers contenant dans /bin qui sont été modifiés sont :${bleu}\n"
awk -F" " '{print $2}' /home/esclave/Desktop/projet/projet/script/failed_hash_bin.txt
else
echo -ne "${rose}Les fichiers contenant dans /bin ne sont pas été  modifiés${bleu}\n"
fi

# Vérification de l'integrité du /sbin
md5deep -X /home/esclave/Desktop/projet/projet/script/hash_sbin.txt -r /sbin > /home/esclave/Desktop/projet/projet/script/failed_hash_sbin.txt
var2=$(wc -w /home/esclave/Desktop/projet/projet/script/failed_hash_sbin.txt | awk '{print $1}')
if [ ! "$var2" = 0 ];
then
echo -ne "${rose}Les fichiers contenant dans /sbin qui sont été modifiés sont :${bleu}\n"
awk -F" " '{print $2}' /home/esclave/Desktop/projet/projet/script/failed_hash_sbin.txt
else
echo -ne "${rose}Les fichiers contenant dans /sbin ne sont pas été  modifiés${bleu}\n"
fi

# Vérification de l'integrité du /usr/bin
md5deep -X /home/esclave/Desktop/projet/projet/script/hash_usr_bin.txt -r /usr/bin > /home/esclave/Desktop/projet/projet/script/failed_hash_usr_bin.txt
var3=$(wc -w /home/esclave/Desktop/projet/projet/script/failed_hash_usr_bin.txt | awk '{print $1}')
if [ ! "$var3" = 0 ];
then
echo -ne "${rose}Les fichiers contenant dans /usr/bin qui sont été modifiés sont:${bleu}\n"
awk -F" " '{print $2}' /home/esclave/Desktop/projet/projet/script/failed_hash_usr_bin.txt
else
echo -ne "${rose}Les fichiers contenant dans /usr/bin ne sont pas été  modifiés${bleu}\n"
fi

# Vérification de l'integrité du /usr/sbin
md5deep -X /home/esclave/Desktop/projet/projet/script/hash_usr_sbin.txt -r /usr/sbin > /home/esclave/Desktop/projet/projet/script/failed_hash_usr_sbin.txt
var4=$(wc -w /home/esclave/Desktop/projet/projet/script/failed_hash_usr_sbin.txt | awk '{print $1}')
if [ ! "$var4" = 0 ];
then
echo -ne "${rose}Les fichiers contenant dans /sbin qui sont été modifiés sont:${bleu}\n"
awk -F" " '{print $2}' /home/esclave/Desktop/projet/projet/script/failed_hash_usr_sbin.txt
else
echo -ne "${rose}Les fichiers contenant dans /usr/sbin ne sont pas été  modifiés${bleu}\n"
fi

echo -ne "${neutre}"

